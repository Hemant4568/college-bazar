import React from 'react'
import HeaderSearch from './HeaderSearch'
import Listing from './Listing'
const Home = () => {
  return (
    <div>
        <Listing/>
    </div>
  )
}

export default Home