import React from 'react'

const Admin = () => {
  return (
    <div>
        <h1>
            admin page
        </h1>
    </div>
  )
}

export default Admin